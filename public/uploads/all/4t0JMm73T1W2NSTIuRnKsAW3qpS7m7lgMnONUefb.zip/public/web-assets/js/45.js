(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[45],{

/***/ "./resources/js/pages/user/EarningPoints.vue":
/*!***************************************************!*\
  !*** ./resources/js/pages/user/EarningPoints.vue ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, exports) {

throw new Error("Module build failed (from ./node_modules/vue-loader/lib/index.js):\nError: ENOENT: no such file or directory, open 'C:\\xampp74\\htdocs\\shop\\resources\\js\\pages\\user\\EarningPoints.vue'");

/***/ })

}]);